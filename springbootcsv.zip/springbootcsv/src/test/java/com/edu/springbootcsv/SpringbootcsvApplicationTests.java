package com.edu.springbootcsv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
